import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Github from './Github';
import Header from './Components/Header';
import Auth0Lock from 'auth0-lock';

class App extends Component {

  constructor(props) {
    super(props);
    
    this.state = {
      iaccessToken: '',
      profile: {}
    };
  }
  





  static defaultProps = {
    clientID: 'JI8XyPadUsKN9b78pIiYjmEKrG4dgbOX',
    domain: 'dev-ov707eym.auth0.com'
  };

  componentWillMount(){

    // for login.. this code.
    this.lock = new Auth0Lock(this.props.clientID, this.props.domain);

    this.lock.on('authenticated', (authResult) => {
      // console.log(authResult);
      
      this.lock.getProfile(authResult.accessToken,(error,profile)=>{
        if(error){
          console.log(error);
          return;
        }
        // console.log(profile);
        
        this.setProfile(authResult.accessToken,profile);

      });
    });
    
    
    this.getProfile(); // if already logged in
  }

  setProfile(accessToken, profile){
    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('profile', JSON.stringify(profile));


    this.setState({
      accessToken:localStorage.getItem('accessToken'),
      profile:JSON.parse(localStorage.getItem('profile'))
    });
  }

  getProfile(){
    if(localStorage.getItem('accessToken') != null){
      this.setState({
        accessToken: localStorage.getItem("accessToken"),
        profile: JSON.parse(localStorage.getItem("profile"))
      }, ()=>{
        console.log(this.state);
        
      });
    }
  }

  showLock(){
    this.lock.show();
  }








  render() {
    let git;

    ///this is the code responsible for login.
    if(this.state.accessToken){
      git = <Github />
    }else{
      git = "Click on Login to view Github viewer"
    }
    ///till this

    return (
      <div className="App">
        <Header 
          onLogin={this.showLock.bind(this)}
        />
          {git}
        <Github />
      </div>
    );
  }
}

export default App;
